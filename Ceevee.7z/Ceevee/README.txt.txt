###Instructions###

This tool will take in csv files and generate a report of detected vulnerabilties. 
First generate your software report from IMIS, then place this is the files/ directory.
Navigate to the bin/ directory and run the main executable, this will prompt you for:

	- The filename, make sure to include the csv extension
	- The option to change the matching ratio

The tool should run for about an hour then it will spit out a report named 'loot.csv'
Errors will be logged in 'errors.txt'
Identified applications are logged in 'id.txt'
Unidentified applications are logged in 'no_id.txt'